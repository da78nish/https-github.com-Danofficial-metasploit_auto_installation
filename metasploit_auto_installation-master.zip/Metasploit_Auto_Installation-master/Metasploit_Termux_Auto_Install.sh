#!/data/data/com.termux/files/usr/bin/bash
pkg install python
pkg install python2
pkg install curl
pkg install wget
pkg install perl
pkg install ruby
pkg install php
wget https://Auxilus.github.io/metasploit.sh
